package etf.dotsandboxes.sd160457d;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.regex.Pattern;

public class Board implements Cloneable {

	public final static int RED = 0;
	public final static int BLUE = 1;
	public final static int BLANK = 2;
	public final static int BLACK = 3;
	
	private int[][] hLines;
	private int[][] vLines;
	private int[][] boxes;
	private int redScore, blueScore;
	private int m, n;
	
	public Board(int m, int n) {
		this.hLines = new int[n][m+1];
		this.vLines = new int[n+1][m];
		this.boxes = new int[n][m];
		this.m = m;
		this.n = n;
		this.blueScore = 0;
		this.redScore = 0;
		
		clear(this.hLines);
		clear(this.vLines);
		clear(this.boxes);
	}
	
	public Board clone() {
		Board cloned = new Board(m,n);

        for(int i=0; i<n; i++)
            for(int j=0; j<m+1; j++)
                cloned.hLines[i][j] = hLines[i][j];

        for(int i=0; i<(n+1); i++)
            for(int j=0; j<m; j++)
                cloned.vLines[i][j] = vLines[i][j];

        for(int i=0; i<n; i++)
            for(int j=0; j<m; j++)
                cloned.boxes[i][j] = boxes[i][j];

        cloned.redScore = redScore;
        cloned.blueScore = blueScore;

        return cloned;     
    }
	
	public Board getNewBoard(Line line, int color) {
        Board ret = clone();
        
        if(line.isHorizontal())
            ret.setHLineColor(line.getX(), line.getY(), color);
        else
            ret.setVLineColor(line.getX(), line.getY(), color);
        
        return ret;
    }
	
	private void clear(int[][] matrix) {
		for(int i=0;i<matrix.length;i++) {
			for(int j=0;j<matrix[0].length;j++) {
				matrix[i][j] = BLANK;
			}
		}
	}
	
	public int[][] getHLines() {
		return hLines;
	}
	
	public int[][] getVLines() {
		return vLines;
	}
	
	public int[][] getBoxes() {
		return boxes;
	}
	
	public int getM() {
		return m;
	}
	
	public int getN() {
		return n;
	}
	
	public int getRedScore() {
		return redScore;
	}
	
	public int getBlueScore() {
		return blueScore;
	}
	
	public int getScore(int color) {
		return color == RED ? redScore : blueScore;
	}
	
	public boolean isComplete() {
		return (redScore+blueScore) == m*n;
	}
	
	public int getWinner() {
		return (blueScore > redScore) ? BLUE : ((blueScore < redScore) ? RED : BLANK);
	}
	
	public ArrayList<Point> setVLineColor(int x, int y, int color) {
		
		try {
			vLines[x][y] = BLACK;
			
			ArrayList<Point> ret = new ArrayList<>();
			
			if (x > 0 && vLines[x-1][y] == BLACK && hLines[x-1][y] == BLACK && hLines[x-1][y+1] == BLACK) {
				boxes[x-1][y] = color;
				ret.add(new Point(x-1,y));
				if (color == RED)
					++redScore;
				else
					++blueScore;
			}
			
			if (x < n && vLines[x+1][y] == BLACK && hLines[x][y] == BLACK && hLines[x][y+1] == BLACK) {
				boxes[x][y] = color;
				ret.add(new Point(x,y));
				if (color == RED)
					++redScore;
				else
					++blueScore;
			}
			
			return ret;
		} catch (Exception e) {
			System.out.println("ERROR MESSAGE: " + e.getLocalizedMessage());
			System.out.println("ERROR VERTICAL");
			return null;
		}
		
	}
	
	public ArrayList<Point> setHLineColor(int x, int y, int color) {
		
		try {
			hLines[x][y] = BLACK;
			String write = new Line(x,y,true).toString();
			
			ArrayList<Point> ret = new ArrayList<>();
			
	
			if (y > 0 && hLines[x][y-1] == BLACK && vLines[x][y-1] == BLACK && vLines[x+1][y-1] == BLACK) {
				boxes[x][y-1] = color;
				ret.add(new Point(x,y-1));
				if (color == RED)
					++redScore;
				else
					++blueScore;
			}
			
			if (y < m && hLines[x][y+1] == BLACK && vLines[x][y] == BLACK && vLines[x+1][y] == BLACK) {
				boxes[x][y] = color;
				ret.add(new Point(x,y));
				if (color == RED)
					++redScore;
				else
					++blueScore;
			}
	
			return ret;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERROR HORIZONTAL");
			return null;
		}
	}
	
	public ArrayList<Line> getAvailableMoves() {
        ArrayList<Line> ret = new ArrayList<Line>();
        
        for(int i=0; i<n;i++)
            for(int j=0; j<(m+1); j++)
                if(hLines[i][j] == BLANK)
                    ret.add(new Line(i,j,true));
        
        for(int i=0; i<(n+1); i++)
            for(int j=0; j<m; j++)
                if(vLines[i][j] == BLANK)
                    ret.add(new Line(i,j,false));
        
        return ret;
    }
	
	private int getLineCount(int i, int j) {
        int count = 0;
        
        if(hLines[i][j] == BLACK) count++;
        if(hLines[i][j+1] == BLACK) count++;
        if(vLines[i][j] == BLACK) count++;
        if(vLines[i+1][j] == BLACK) count++;
        
        return count;
    }
	
	public int getBoxesCount(int num_sides) {
		int count = 0;
		
		for(int i=0; i<n; i++) {
			for(int j=0; j<m; j++) {
				if (getLineCount(i,j) == num_sides)
					++count;
			}
		}
		
		return count;
	}
}
