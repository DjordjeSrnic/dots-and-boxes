package etf.dotsandboxes.sd160457d;

public class CachedValue {
	
	private Pair move;
	private int depth;
	private int upperbound;
	private int lowerbound;
	
	
	public CachedValue(Pair move, int depth) {
	    this.move = move;
	    this.depth = depth;
	}
	
	public Pair getMove() {
		return move;
	}

	public int getDepth() {
		return depth;
	}
	
	public int getUpperbound() {
		return upperbound;
	}
	
	public void setUpperbound(int upperbound) {
		this.upperbound = upperbound;
	}
	
	public int getLowerbound() {
		return lowerbound;
	}
	
	public void setLowerbound(int lowerbound) {
		this.lowerbound = lowerbound;
	}
}
