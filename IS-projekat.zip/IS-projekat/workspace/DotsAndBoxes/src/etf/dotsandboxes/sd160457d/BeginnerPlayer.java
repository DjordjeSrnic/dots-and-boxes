package etf.dotsandboxes.sd160457d;

import java.util.ArrayList;
import java.util.Random;

public class BeginnerPlayer extends Player {

	@Override
	public Line getNextMove(Board board, int color) {
		ArrayList<Line> moves = board.getAvailableMoves();
        ArrayList<Line> bMoves = new ArrayList<Line>();
        
        for(Line move : moves) {
        	Board newBoard = board.getNewBoard(move, color);
        	if(newBoard.getScore(color) > board.getScore(color))
        		bMoves.add(move);
        }
        
        if(!bMoves.isEmpty()) 
        	moves = bMoves;
        
        return moves.get(new Random().nextInt(moves.size()));
	}

}
