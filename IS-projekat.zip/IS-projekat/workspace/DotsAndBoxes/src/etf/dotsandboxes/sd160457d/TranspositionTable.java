package etf.dotsandboxes.sd160457d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class TranspositionTable {

	private final static long[] randomNumbers = new long[400];

	static {
		Random random = new Random(58139);
		for(int i=0; i < 400; i++) {
			randomNumbers[i] = random.nextLong();
		}
	}
	
	private final Map<Long, CachedValue> map = new HashMap<>();
	
	public void put(Board board, CachedValue cachedValue) {
		long hash = calculateHash(board); 
	    map.put(hash, cachedValue);
	}
	
	public CachedValue get(Board board) {
		long hash = calculateHash(board);
	    return map.get(hash);
	}

	public void clear() {
	    map.clear();
	}
	
	private long calculateHash(Board board) {
		long hash = 0;
		int[][] hLines = board.getHLines();
		int[][] vLines = board.getVLines();
		int[][] boxes = board.getBoxes();
		
		for(int i=0; i < hLines.length; i++)
			for(int j=0; j < hLines[0].length; j++)
				if (hLines[i][j] == Board.BLACK)
					hash ^= randomNumbers[i*hLines[0].length+j];
		
		int numH = hLines.length*hLines[0].length;
		
		for(int i=0; i < vLines.length; i++)
			for(int j=0; j < vLines[0].length; j++)
				if (vLines[i][j] == Board.BLACK)
					hash ^= randomNumbers[numH + i*vLines[0].length + j];

		int numV = vLines.length*vLines[0].length;
		
		int numB = boxes.length*boxes[0].length;
		
		for(int i=0; i < boxes.length; i++)
			for(int j=0; j < boxes[0].length; j++)
				if (boxes[i][j] == Board.RED)
					hash ^= randomNumbers[numH + numV + i*boxes[0].length + j];
				else if (boxes[i][j] == Board.BLUE)
					hash ^= randomNumbers[numH + numV + numB + i*boxes[0].length + j];
		
		return hash;
	}
}
