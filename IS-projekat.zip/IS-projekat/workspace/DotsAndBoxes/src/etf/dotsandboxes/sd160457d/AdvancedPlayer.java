package etf.dotsandboxes.sd160457d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class AdvancedPlayer extends Player {

	final static int MIN=-1000000000, MAX=1000000000 ;
    private int maxDepth;
    private int numCalls = 0;

    @Override
    public Line getNextMove(Board board, int color) {
    	ArrayList<Line> moves = board.getAvailableMoves();
        ArrayList<Line> bMoves = new ArrayList<Line>();
        referenceColor = color;
        
        for(Line move : moves) {
        	Board newBoard = board.getNewBoard(move, color);
        	if(newBoard.getScore(color) > board.getScore(color))
        		bMoves.add(move);
        }
        
        if(!bMoves.isEmpty()) {
        	return bMoves.get(new Random().nextInt(bMoves.size()));
        }
        
        numCalls =0;
    	Pair bestMove = alphaBetaMinimax(board, color, MIN, MAX, maxDepth);
    

    	Line line = bestMove.getLine();
    	line.setHeuristic(bestMove.getHeuristic());
    	
    	System.out.println("NUM CALLS ADVANCED: " + numCalls);
    	return bestMove.getLine();
    }

    public Pair alphaBetaMinimax(Board board, int color, int alpha, int beta, int depth) {
           
    	++numCalls; 
    	
    	if (depth == 0 || board.isComplete())
        	return new Pair(null, heuristic(board, color));
    	
    	ArrayList<Line> moves = board.getAvailableMoves();
    	int num_of_children = moves.size();
    	
    	int value;

    	if (color == Board.BLUE) {
    		value = MIN;
    		Pair bestMove = new Pair(null, MIN);
    		
    		
    		for(int i=0;i<num_of_children;i++) {
    			Board child = board.getNewBoard(moves.get(i), color);
    			if (child.getBoxesCount(3) > board.getBoxesCount(3))
    				continue;
    			
    			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);
    			
    			if (res.getHeuristic() > value) {
    				bestMove.setHeuristic(res.getHeuristic());
    				bestMove.setLine(moves.get(i));
    				value = res.getHeuristic();
    			}
    			
    			alpha = Math.max(alpha, value);
    			if (alpha >= beta)
    				break;
    		}
    		
    		if (bestMove.getLine() == null) {
    			value = MIN;
    			for(int i=0;i<num_of_children;i++) {
        			Board child = board.getNewBoard(moves.get(i), color);
        			
        			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);
        			
        			if (res.getHeuristic() > value) {
        				bestMove.setHeuristic(res.getHeuristic());
        				bestMove.setLine(moves.get(i));
        				value = res.getHeuristic();
        			}
        			
        			alpha = Math.max(alpha, value);
        			if (alpha >= beta)
        				break;
        		}
    		}
    		
    		return bestMove;
    	} else {
    		value = MAX;
    		Pair bestMove = new Pair(null, MAX);
    		for(int i=0;i<num_of_children;i++) {
    			Board child = board.getNewBoard(moves.get(i), color);
    			if (child.getBoxesCount(3) > board.getBoxesCount(3))
    				continue;
    			
    			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);

    			if (res.getHeuristic() < value) {
    				bestMove.setHeuristic(res.getHeuristic());
    				bestMove.setLine(moves.get(i));
    				value = res.getHeuristic();
    			}
    			
    			beta = Math.min(beta, value);
    			
    			if (alpha >= beta)
    				break;
    		}
    		
    		if (bestMove.getLine() == null) {
    			value = MAX;
    			for(int i=0;i<num_of_children;i++) {
        			Board child = board.getNewBoard(moves.get(i), color);
	
        			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);

        			if (res.getHeuristic() < value) {
        				bestMove.setHeuristic(res.getHeuristic());
        				bestMove.setLine(moves.get(i));
        				value = res.getHeuristic();
        			}
        			
        			beta = Math.min(beta, value);
        			
        			if (alpha >= beta)
        				break;
        		}
    		}

    		return bestMove;
    	}
    }
        
    public void setMaxDepth(int maxDepth) {
    	this.maxDepth = maxDepth;
    }   
        
    public int getMaxDepth() {
    	return maxDepth;
    }
}
