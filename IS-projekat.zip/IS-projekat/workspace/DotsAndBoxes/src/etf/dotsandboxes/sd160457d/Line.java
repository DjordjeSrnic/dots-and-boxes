package etf.dotsandboxes.sd160457d;

public class Line {

	private int x, y;
	private int heuristic;
	private boolean horizontal;
	
	public Line() {
        x = -1;
        y = -1;
        horizontal = false;
	}
	
	public Line(int x, int y, boolean horizontal) {
		this.x = x;
		this.y = y;
		this.horizontal = horizontal;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setHeuristic(int heuristic) {
		this.heuristic = heuristic;
	}
	
	public double getHeuristic() {
		return heuristic;
	}
	
	public boolean isHorizontal() {
		return horizontal;
	}
	
	@Override
	public String toString() {
		String ret = "";
		if (horizontal) {
			ret += "" + y + Character.toString((char)(x + 65));
		} else {
			ret += "" + Character.toString((char)(y + 65)) + x;
		}
		
		ret += " | " + heuristic;
		
		return ret;
	}
}
