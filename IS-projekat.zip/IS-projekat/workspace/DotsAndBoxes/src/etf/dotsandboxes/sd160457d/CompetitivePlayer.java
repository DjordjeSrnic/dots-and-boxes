package etf.dotsandboxes.sd160457d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class CompetitivePlayer extends Player {

	final static int MIN=-1000000000, MAX=1000000000 ;
    private int maxDepth;
    private final TranspositionTable transpositionTable = new TranspositionTable();
    private int numCalls = 0;
    private int numTrans = 0;

    @Override
    protected int heuristic(final Board board, int color) {
        int value;
        
        if(referenceColor == Board.RED)
            value = cScore * board.getScore(RED) - cScore * board.getScore(BLUE);
        else
            value = cScore * board.getScore(BLUE) - cScore * board.getScore(RED);
      
        
        if(referenceColor == color)
            value += cThree * board.getBoxesCount(3) - cTwo * board.getBoxesCount(2);
        else
            value -= cThree * board.getBoxesCount(3) - cTwo * board.getBoxesCount(2);
      
        
        return value;
    }
    
    @Override
    public Line getNextMove(Board board, int color) {
    	ArrayList<Line> moves = board.getAvailableMoves();
        ArrayList<Line> bMoves = new ArrayList<Line>();
        referenceColor = color;
        for(Line move : moves) {
        	Board newBoard = board.getNewBoard(move, color);
        	if(newBoard.getScore(color) > board.getScore(color))
        		bMoves.add(move);
        }
        
        if(!bMoves.isEmpty()) {
        	return bMoves.get(new Random().nextInt(bMoves.size()));
        }
        
        numCalls = 0;
        numTrans = 0;
    	Pair bestMove = alphaBetaMinimax(board, color, MIN, MAX, maxDepth);
    	//System.out.println("NUM CALLS COMP: " + numCalls);
    	//System.out.println("NUM CALLS TRANS: " + numTrans);
    	
    	Line line = bestMove.getLine();
    	line.setHeuristic(bestMove.getHeuristic());

    	return bestMove.getLine();
    }
    
    public Pair alphaBetaMinimax(Board board, int color, int alpha, int beta, int depth) {
            	
    	++numCalls;
    	
    	CachedValue cachedValue = transpositionTable.get(board);
    	
    	if (cachedValue != null && cachedValue.getDepth() >= depth) {
    		Pair move = cachedValue.getMove();
    		
    		if (cachedValue.getLowerbound() >= beta) {
    			move.setHeuristic(cachedValue.getLowerbound());
    			return move;
    		}
    		
    		if (cachedValue.getUpperbound() <= alpha) {
    			move.setHeuristic(cachedValue.getUpperbound()); 
    			return move;
    		}
    		
    		alpha = Math.max(alpha, cachedValue.getLowerbound());
    		beta = Math.min(beta, cachedValue.getUpperbound());
    		
    		/*if (flag == CachedValue.Flag.LOWERBOUND && move.getHeuristic() >= beta) {
    			return move;
    		}
    		else if (flag == CachedValue.Flag.UPPERBOUND && move.getHeuristic() <= alpha) {
    			return move;
    		}
    		else if (flag == CachedValue.Flag.EXACT && (move.getHeuristic() >= beta || move.getHeuristic() <= alpha)) {
    			return move;
    		}
    		
    		
    		if (flag == CachedValue.Flag.LOWERBOUND || flag == CachedValue.Flag.EXACT) {
    			alpha = Math.max(alpha, move.getHeuristic());
    		}
    			
    		
    		if (flag == CachedValue.Flag.UPPERBOUND || flag == CachedValue.Flag.EXACT) {
    			beta = Math.min(beta, move.getHeuristic());
    		}*/
    		
    	}
    	
    	int originalAlpha = alpha;
    	int originalBeta = beta;
    	
    	if (depth == 0 || board.isComplete()) {
    		CachedValue newCachedValue = new CachedValue(new Pair(null, heuristic(board, color)), depth);
    		
    		newCachedValue.setUpperbound(originalBeta);
        	newCachedValue.setLowerbound(originalAlpha);
    		
    		if (heuristic(board, color) <= originalAlpha)
        		newCachedValue.setUpperbound(heuristic(board, color));
        	
    		if (heuristic(board, color) > originalAlpha && heuristic(board, color) < originalBeta){
    			newCachedValue.setUpperbound(heuristic(board, color));
    			newCachedValue.setLowerbound(heuristic(board, color));
    		} 
    		
    		if (heuristic(board, color) >= originalBeta)
        		newCachedValue.setLowerbound(heuristic(board, color));
    			
    		
    		transpositionTable.put(board, newCachedValue);
			
        	return new Pair(null, heuristic(board, color));
    	}
    	
    	ArrayList<Line> moves = board.getAvailableMoves();
    	int num_of_children = moves.size();
    	
    	int value;
    	Pair bestMove;
    	CachedValue newCachedValue;
    	
    	if (color == Board.BLUE) {
    		value = MIN;
    		bestMove = new Pair(null, MIN);
    		
    		
    		for(int i=0;i<num_of_children;i++) {
    			Board child = board.getNewBoard(moves.get(i), color);
    			if (child.getBoxesCount(3) > board.getBoxesCount(3))
    				continue;
    			
    			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);
    			
    			if (res.getHeuristic() > value) {
    				bestMove.setHeuristic(res.getHeuristic());
    				bestMove.setLine(moves.get(i));
    				value = res.getHeuristic();
    			}
    			
    			alpha = Math.max(alpha, value);
    			if (value >= beta)
    				break;
    			
    		}
    		
    		if (bestMove.getLine() == null) {
    			value = MIN;
    			for(int i=0;i<num_of_children;i++) {
        			Board child = board.getNewBoard(moves.get(i), color);
        			
        			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);
        			
        			if (res.getHeuristic() > value) {
        				bestMove.setHeuristic(res.getHeuristic());
        				bestMove.setLine(moves.get(i));
        				value = res.getHeuristic();
        			}
        			
        			alpha = Math.max(alpha, value);
        			if (value >= beta)
        				break;
        			
        		}
    			
    		} 

    	} else {
    		value = MAX;
    		bestMove = new Pair(null, MAX);
    		for(int i=0;i<num_of_children;i++) {
    			Board child = board.getNewBoard(moves.get(i), color);
    			if (child.getBoxesCount(3) > board.getBoxesCount(3))
    				continue;
    			
    			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);

    			if (res.getHeuristic() < value) {
    				bestMove.setHeuristic(res.getHeuristic());
    				bestMove.setLine(moves.get(i));
    				value = res.getHeuristic();
    			}
    			
    			beta = Math.min(beta, value);
    			
    			if (value <= alpha)
    				break;
    			
    		}
    		
    		
    		if (bestMove.getLine() == null) {
    			value = MAX;
    			for(int i=0;i<num_of_children;i++) {
        			Board child = board.getNewBoard(moves.get(i), color);
	
        			Pair res = alphaBetaMinimax(child, color == Board.BLUE ? Board.RED : Board.BLUE, alpha, beta, depth - 1);

        			if (res.getHeuristic() < value) {
        				bestMove.setHeuristic(res.getHeuristic());
        				bestMove.setLine(moves.get(i));
        				value = res.getHeuristic();
        			}
        			
        			beta = Math.min(beta, value);
        			
        			if (value <= alpha)
        				break;
        			
        		}
    		}
    		
    	}
    	
    	newCachedValue = new CachedValue(bestMove, depth);
    	
    	newCachedValue.setUpperbound(originalBeta);
    	newCachedValue.setLowerbound(originalAlpha);

    	if (bestMove.getHeuristic() <= originalAlpha)
    		newCachedValue.setUpperbound(bestMove.getHeuristic());
    	
		if (bestMove.getHeuristic() > originalAlpha && bestMove.getHeuristic() < originalBeta){
			newCachedValue.setUpperbound(bestMove.getHeuristic());
			newCachedValue.setLowerbound(bestMove.getHeuristic());
		} 
		
		if (bestMove.getHeuristic() >= originalBeta)
    		newCachedValue.setLowerbound(bestMove.getHeuristic());
		
		transpositionTable.put(board, newCachedValue);
		
		return bestMove;
    }
        
    public void setMaxDepth(int maxDepth) {
    	this.maxDepth = maxDepth;
    }   
        
    public int getMaxDepth() {
    	return maxDepth;
    }
    
}
