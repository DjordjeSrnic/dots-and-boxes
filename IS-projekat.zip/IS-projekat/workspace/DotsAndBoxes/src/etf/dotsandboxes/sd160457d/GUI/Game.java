package etf.dotsandboxes.sd160457d.GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.net.ssl.SNIHostName;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

import etf.dotsandboxes.sd160457d.Board;
import etf.dotsandboxes.sd160457d.Line;
import etf.dotsandboxes.sd160457d.Player;

public class Game {

	public final static int SBS = 0;
	public final static int IMM = 1;
	
	private final static int size = 10;
    private final static int dist = 40;

    private int n, m;
    private Board board;
    private int turn;
    private boolean mouseEnabled;
    
    private JLabel[][] hLine, vLine, box;
    private boolean[][] isSetHLine, isSetVLine;

    private Player redPlayer, bluePlayer, player;
    private String redName, blueName;
    
    private JFrame frame;
    private JLabel redScoreLabel, blueScoreLabel, statusLabel;
    private JButton mainMenu;
    private JButton nextStep;
    
    private JList<String> movesList;
    private DefaultListModel<String> model;
    
    private int workMode = IMM;
    
    private MainFrame parent;
    
    private File outputFile;
    private BufferedWriter out;
    private StringBuilder sb;
	
	private MouseListener mouseListener = new MouseListener() {

        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
            if(!mouseEnabled) 
            	return;
            processMove(getSource(mouseEvent.getSource()));
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {
            if(!mouseEnabled) 
            	return;
            
            Line line = getSource(mouseEvent.getSource());
            int x=line.getX(), y=line.getY();
            
            if(line.isHorizontal()) {
                if(isSetHLine[x][y]) 
                	return;
                hLine[x][y].setBackground((turn == Board.RED) ? Color.RED : Color.BLUE);
            } else {
                if(isSetVLine[x][y]) 
                	return;
                vLine[x][y].setBackground((turn == Board.RED) ? Color.RED : Color.BLUE);
            }
        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {
            if(!mouseEnabled) 
            	return;
            
            Line line = getSource(mouseEvent.getSource());
            int x=line.getX(), y=line.getY();
            
            if(line.isHorizontal()) {
                if(isSetHLine[x][y]) 
                	return;
                hLine[x][y].setBackground(Color.WHITE);
            }
            else {
                if(isSetVLine[x][y]) 
                	return;
                vLine[x][y].setBackground(Color.WHITE);
            }
        }
    };
    
    public Game(MainFrame parent, JFrame frame, int n, int m, Player redPlayer, Player bluePlayer, String redName, String blueName, int workMode) throws Exception {
        this.parent = parent;
        this.frame = frame;
        this.n = n;
        this.m = m;
        this.redPlayer = redPlayer;
        this.bluePlayer = bluePlayer;
        this.redName = redName;
        this.blueName = blueName;
        this.workMode = workMode;
        
        //C:\\Users\\Djordje\\Desktop\\IS - projekat\\workspace\\DotsAndBoxes\\
        this.sb = new StringBuilder();
        this.sb.append(m + " " + n + "\n");
        this.outputFile = new File("output_file.txt");
		if (outputFile.exists()) 
			outputFile.delete();
	
        this.model = new DefaultListModel<>();
        this.movesList = new JList<>(model);
        this.movesList.setVisibleRowCount(10);
        this.movesList.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        this.mainMenu = new JButton("Main Menu");
        this.mainMenu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!board.isComplete()) {
					try {
						out = new BufferedWriter(new FileWriter(outputFile));
						out.write(sb.toString());
						out.close();
					} catch(Exception e) {}
				}
				goBack = true;
			}
        	
        });
        
        this.nextStep = new JButton("Next Step");
        if (workMode == SBS)
        	nextStep.setEnabled(true);
        else
        	nextStep.setEnabled(false);
        this.nextStep.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!board.isComplete()) {
					processMove(player.getNextMove(board, turn));
					if (board.isComplete()) {
						nextStep.setEnabled(false);
						try {
							out = new BufferedWriter(new FileWriter(outputFile));
							out.write(sb.toString());
							out.close();
						} catch (Exception e) {}
					}
				}
			}
        	
        });
        
        initGame();
    }
    
    public Game(MainFrame parent, JFrame frame, File file, Player redPlayer, Player bluePlayer, String redName, String blueName, int workMode) throws Exception {
        this.parent = parent;
        this.frame = frame;
        
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        StringBuffer sb = new StringBuffer ();
        
        String dim = "";
        String s;
        
        while ((s = in.readLine()) != null){
			if ("".equals(dim))
				dim = s;
			else
				sb.append(s+"\n");
		}
        
        String[] moves = sb.toString().split("\n");
        
        this.m = Integer.parseInt(dim.split(" ")[0]);
		this.n = Integer.parseInt(dim.split(" ")[1]);
        this.redPlayer = redPlayer;
        this.bluePlayer = bluePlayer;
        this.redName = redName;
        this.blueName = blueName;
        this.workMode = workMode;
        
        this.sb = new StringBuilder();
        this.sb.append(m + " " + n + "\n");
        this.outputFile = new File("output_file.txt");
		if (outputFile.exists()) 
			outputFile.delete();
		
		try {
			out = new BufferedWriter(new FileWriter(this.outputFile, true));
		} catch (IOException e) {}
        
        this.model = new DefaultListModel<>();
        this.movesList = new JList<>(model);
        this.movesList.setVisibleRowCount(10);
        this.movesList.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        this.mainMenu = new JButton("Main Menu");
        this.mainMenu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!board.isComplete()) {
					try {
						out = new BufferedWriter(new FileWriter(outputFile));
						out.write(sb.toString());
						out.close();
					} catch(Exception e) {}
				}
				goBack = true;
			}
        	
        });
        
        this.nextStep = new JButton("Next Step");
        if (workMode == SBS)
        	nextStep.setEnabled(true);
        else
        	nextStep.setEnabled(false);
        this.nextStep.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (!board.isComplete()) {
					processMove(player.getNextMove(board, turn));
					if (board.isComplete()) {
						nextStep.setEnabled(false);
						try {
							out = new BufferedWriter(new FileWriter(outputFile));
							out.write(sb.toString());
							out.close();
						} catch (Exception e) {}
					}
				}
			}
        	
        });
        in.close();
        initGame(moves);
    }
    
    private void processMove(Line line) {
        int x=line.getX(), y=line.getY();
        
        ArrayList<Point> ret;
        
		if(line.isHorizontal()) {
            if(isSetHLine[x][y]) {
            	return;
            }
            
            model.addElement(line.toString());
            sb.append(line.toString().substring(0, line.toString().indexOf("|")) + "\n");

            ret = board.setHLineColor(x,y,turn);
            
         
            hLine[x][y].setBackground(Color.BLACK);
            isSetHLine[x][y] = true;
        } else {
            if(isSetVLine[x][y]) {
            	return;
            }
            
            model.addElement(line.toString());
            sb.append(line.toString().substring(0, line.toString().indexOf("|")) + "\n");
            
            ret = board.setVLineColor(x,y,turn);
            vLine[x][y].setBackground(Color.BLACK);
            isSetVLine[x][y] = true;
        }

        for(Point p : ret)
            box[p.x][p.y].setBackground((turn == Board.RED) ? Color.RED : Color.BLUE);

        redScoreLabel.setText(String.valueOf(board.getRedScore()));
        blueScoreLabel.setText(String.valueOf(board.getBlueScore()));

        if(board.isComplete()) {
            int winner = board.getWinner();
            if(winner == Board.RED) {
                statusLabel.setText("Player-2 is the winner!");
                statusLabel.setForeground(Color.RED);
            }
            else if(winner == Board.BLUE) {
                statusLabel.setText("Player-1 is the winner!");
                statusLabel.setForeground(Color.BLUE);
            }
            else {
                statusLabel.setText("Game Tied!");
                statusLabel.setForeground(Color.BLACK);
            }
        }

        if(ret.isEmpty()) {
            if(turn == Board.RED) {
                turn = Board.BLUE;
                player = bluePlayer;
                statusLabel.setText("Player-1's Turn...");
                statusLabel.setForeground(Color.BLUE);
            }
            else {
                turn = Board.RED;
                player = redPlayer;
                statusLabel.setText("Player-2's Turn...");
                statusLabel.setForeground(Color.RED);
            }
        }

    }
    
    private void manageGame() {
    	
        while(!board.isComplete()) {
            if(player == null) {
                mouseEnabled = true;
            }
            else {
                mouseEnabled = false;
                processMove(player.getNextMove(board, turn));
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    private Line getSource(Object object) {
	    for(int i=0; i<n; i++)
	        for(int j=0; j<(m+1); j++)
	            if(hLine[i][j] == object)
	            	 return new Line(i,j,true);

	    for(int i=0; i<(n+1); i++)
	        for(int j=0; j<m; j++) {
	            if(vLine[i][j] == object)
	                return new Line(i,j,false);
	        }
    	
       return new Line();
    }
    
    private boolean goBack = false;

    
    private JLabel getHorizontalLine() {
        JLabel label = new JLabel();
        label.setPreferredSize(new Dimension(dist, size));
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label.setOpaque(true);
        label.addMouseListener(mouseListener);
        return label;
    }

    private JLabel getVerticalLine() {
        JLabel label = new JLabel();
        label.setPreferredSize(new Dimension(size, dist));
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label.setOpaque(true);
        label.addMouseListener(mouseListener);
        return label;
    }

    private JLabel getDot() {
        JLabel label = new JLabel();
        label.setPreferredSize(new Dimension(size, size));
        label.setBackground(Color.BLACK);
        label.setOpaque(true);
        return label;
    }

    private JLabel getBox() {
        JLabel label = new JLabel();
        label.setPreferredSize(new Dimension(dist, dist));
        label.setOpaque(true);
        return label;
    }

    private JLabel getEmptyLabel(Dimension d) {
        JLabel label = new JLabel();
        label.setPreferredSize(d);
        return label;
    }
    
    
    private void initGame() throws Exception {

        board = new Board(m,n);
        int boardWidth = (m+1) * size + n * dist;
        turn = Board.BLUE;
        player = bluePlayer;

        JPanel grid = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);
        
        JPanel playerPanel = new JPanel(new GridLayout(2, 2));
        if(n>3) playerPanel.setPreferredSize(new Dimension(2 * boardWidth, dist));
        else playerPanel.setPreferredSize(new Dimension(2 * boardWidth, 2 * dist));
        playerPanel.add(new JLabel("<html><font color='blue'>Player-1:", SwingConstants.CENTER));
        playerPanel.add(new JLabel("<html><font color='red'>Player-2:", SwingConstants.CENTER));
        playerPanel.add(new JLabel("<html><font color='blue'>" + blueName, SwingConstants.CENTER));
        playerPanel.add(new JLabel("<html><font color='red'>" + redName, SwingConstants.CENTER));
        ++constraints.gridy;
        grid.add(playerPanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);

        JPanel scorePanel = new JPanel(new GridLayout(2, 2));
        scorePanel.setPreferredSize(new Dimension(2 * boardWidth, dist));
        scorePanel.add(new JLabel("<html><font color='blue'>Score:", SwingConstants.CENTER));
        scorePanel.add(new JLabel("<html><font color='red'>Score:", SwingConstants.CENTER));
        blueScoreLabel = new JLabel("0", SwingConstants.CENTER);
        blueScoreLabel.setForeground(Color.BLUE);
        scorePanel.add(blueScoreLabel);
        redScoreLabel = new JLabel("0", SwingConstants.CENTER);
        redScoreLabel.setForeground(Color.RED);
        scorePanel.add(redScoreLabel);
        ++constraints.gridy;
        grid.add(scorePanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);

        hLine = new JLabel[n][m+1];
        isSetHLine = new boolean[n][m+1];

        vLine = new JLabel[n+1][m];
        isSetVLine = new boolean[n+1][m];

        box = new JLabel[n][m];

        for(int i=0; i<(2*m+1); i++) {
            JPanel pane = new JPanel(new FlowLayout(FlowLayout.CENTER,0,0));
            
            if(i%2==0) {
                pane.add(getDot());
                for(int j=0; j<n; j++) {
                    hLine[j][i/2] = getHorizontalLine();
                    pane.add(hLine[j][i/2]);
                    pane.add(getDot());
                }
            }
            else {
                for(int j=0; j<n; j++) {
                    vLine[j][i/2] = getVerticalLine();
                    pane.add(vLine[j][i/2]);
                    box[j][i/2] = getBox();
                    pane.add(box[j][i/2]);
                }
                vLine[n][i/2] = getVerticalLine();
                pane.add(vLine[n][i/2]);
            }
            ++constraints.gridy;
            grid.add(pane, constraints);
        }
        
        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);

        statusLabel = new JLabel("Player-1's Turn...", SwingConstants.CENTER);
        statusLabel.setForeground(Color.BLUE);
        statusLabel.setPreferredSize(new Dimension(2 * boardWidth, dist));
        ++constraints.gridy;
        grid.add(statusLabel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);
        
        JPanel buttonPanel = new JPanel(new GridLayout(1,2));
        buttonPanel.add(mainMenu);
        buttonPanel.add(nextStep);
        ++constraints.gridy;
        grid.add(buttonPanel, constraints);
        
        grid.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        JPanel listPanel = new JPanel();
        listPanel.add(movesList);

        frame.getContentPane().removeAll();
        frame.revalidate();
        frame.repaint();
        


        JScrollPane scrollPane = new JScrollPane(movesList);
        JPanel scrollPanel = new JPanel();
        scrollPanel.add(scrollPane);
        
        
        //scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        //scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        
        frame.add(grid);
        frame.add(scrollPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        
        if (workMode != SBS) {
        	manageGame();
        	try {
				out = new BufferedWriter(new FileWriter(outputFile));
				out.write(sb.toString());
				out.close();
			} catch (Exception e) {}
        }
        
        while(!goBack) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        parent.initGUI();
    }
    
    private void initGame(String[] moves) throws Exception {

        board = new Board(m,n);
        int boardWidth = (m+1) * size + n * dist;
        turn = Board.BLUE;
        player = bluePlayer;

        JPanel grid = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);
        
        JPanel playerPanel = new JPanel(new GridLayout(2, 2));
        if(n>3) playerPanel.setPreferredSize(new Dimension(2 * boardWidth, dist));
        else playerPanel.setPreferredSize(new Dimension(2 * boardWidth, 2 * dist));
        playerPanel.add(new JLabel("<html><font color='blue'>Player-1:", SwingConstants.CENTER));
        playerPanel.add(new JLabel("<html><font color='red'>Player-2:", SwingConstants.CENTER));
        playerPanel.add(new JLabel("<html><font color='blue'>" + blueName, SwingConstants.CENTER));
        playerPanel.add(new JLabel("<html><font color='red'>" + redName, SwingConstants.CENTER));
        ++constraints.gridy;
        grid.add(playerPanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);

        JPanel scorePanel = new JPanel(new GridLayout(2, 2));
        scorePanel.setPreferredSize(new Dimension(2 * boardWidth, dist));
        scorePanel.add(new JLabel("<html><font color='blue'>Score:", SwingConstants.CENTER));
        scorePanel.add(new JLabel("<html><font color='red'>Score:", SwingConstants.CENTER));
        blueScoreLabel = new JLabel("0", SwingConstants.CENTER);
        blueScoreLabel.setForeground(Color.BLUE);
        scorePanel.add(blueScoreLabel);
        redScoreLabel = new JLabel("0", SwingConstants.CENTER);
        redScoreLabel.setForeground(Color.RED);
        scorePanel.add(redScoreLabel);
        ++constraints.gridy;
        grid.add(scorePanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);

        hLine = new JLabel[n][m+1];
        isSetHLine = new boolean[n][m+1];

        vLine = new JLabel[n+1][m];
        isSetVLine = new boolean[n+1][m];

        box = new JLabel[n][m];

        for(int i=0; i<(2*m+1); i++) {
            JPanel pane = new JPanel(new FlowLayout(FlowLayout.CENTER,0,0));
     
            if(i%2==0) {
                pane.add(getDot());
                for(int j=0; j<n; j++) {
                    hLine[j][i/2] = getHorizontalLine();
                    pane.add(hLine[j][i/2]);
                    pane.add(getDot());
                }
            }
            else {
                for(int j=0; j<n; j++) {
                    vLine[j][i/2] = getVerticalLine();
                    pane.add(vLine[j][i/2]);
                    box[j][i/2] = getBox();
                    pane.add(box[j][i/2]);
                }
                vLine[n][i/2] = getVerticalLine();
                pane.add(vLine[n][i/2]);
            }
            ++constraints.gridy;
            grid.add(pane, constraints);
        }
        
        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);

        statusLabel = new JLabel("Player-1's Turn...", SwingConstants.CENTER);
        statusLabel.setForeground(Color.BLUE);
        statusLabel.setPreferredSize(new Dimension(2 * boardWidth, dist));
        ++constraints.gridy;
        grid.add(statusLabel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(2 * boardWidth, 10)), constraints);
        
        JPanel buttonPanel = new JPanel(new GridLayout(1,2));
        buttonPanel.add(mainMenu);
        buttonPanel.add(nextStep);
        ++constraints.gridy;
        grid.add(buttonPanel, constraints);
        
        grid.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        JPanel listPanel = new JPanel();
        listPanel.add(movesList);

        frame.getContentPane().removeAll();
        frame.revalidate();
        frame.repaint();
        
        
        JScrollPane scrollPane = new JScrollPane(movesList);
        JPanel scrollPanel = new JPanel();
        scrollPanel.add(scrollPane);
        
        frame.add(grid);
        frame.add(scrollPane);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        for(int i=0;i<moves.length;i++) {
        	int x, y;
        	boolean horizontal;
			
			if (Character.isLetter(moves[i].charAt(0))) {
				x = Integer.parseInt(moves[i].split("")[1]);
				y = moves[i].charAt(0) - 65;
				horizontal = false;
			} else {
				y = Integer.parseInt(moves[i].split("")[0]);
				x = moves[i].charAt(1) - 65;
				horizontal = true;
			}
			Line line = new Line(x,y,horizontal);
			processMove(line);
        }

        if (workMode != SBS) {
        	manageGame();
        	try {
				out = new BufferedWriter(new FileWriter(outputFile));
				out.write(sb.toString());
				out.close();
			} catch (Exception e) {}
        }
        
        while(!goBack) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        parent.initGUI();
    }
}
