package etf.dotsandboxes.sd160457d.GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import etf.dotsandboxes.sd160457d.AdvancedPlayer;
import etf.dotsandboxes.sd160457d.BeginnerPlayer;
import etf.dotsandboxes.sd160457d.CompetitivePlayer;
import etf.dotsandboxes.sd160457d.Player;

public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private int n, m;
    private Player redPlayer, bluePlayer;
    private String redName, blueName;
    private int workMode = Game.IMM;
    private int maxDepth;

    private JFrame frame;
    private JLabel modeError, sizeError, depthError, workModeError;
    private JTextField maxDepthInput, nInput, mInput;
    private JFileChooser fc;
    private JCheckBox fileCheckBox;
    private JButton selectFile;
    private JButton submitButton;
    private File file;
    
    String[] players = {"Select player", "Human", "Beginner", "Advanced", "Competitive"};
    String[] work_modes = {"Select work mode", "Step-by-step", "Immediate"};

    JComboBox<String> redList, blueList, workModeList;
	
	public MainFrame() {
		frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        redList = new JComboBox<String>(players);
        blueList = new JComboBox<String>(players);
        workModeList = new JComboBox<String>(work_modes);
        workModeList.setEnabled(false);
        maxDepthInput = new JTextField(4);
        maxDepthInput.setText("0");
        maxDepthInput.setEnabled(false);
        mInput = new JTextField(4);
        mInput.setText("0");
        nInput = new JTextField(4);
        nInput.setText("0");
        
        fc = new JFileChooser();
        selectFile = new JButton("Start With A File");
        selectFile.setEnabled(false);
        
        fileCheckBox = new JCheckBox("Use File?");
        fileCheckBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					selectFile.setEnabled(true);
					submitButton.setEnabled(false);
				} else {
					selectFile.setEnabled(false);
					submitButton.setEnabled(true);
				}
					
			}
        });
        
        submitButton = new JButton("Start Game");
        submitButton.addActionListener(submitListener);
        
        selectFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (e.getSource() == selectFile) {
						int returnVal = fc.showOpenDialog(frame);
						if (returnVal == JFileChooser.APPROVE_OPTION) {
							file = fc.getSelectedFile();
							int rIndex = redList.getSelectedIndex();
				            int bIndex = blueList.getSelectedIndex();
				            if(rIndex==0 || bIndex==0) {
				                modeError.setText("You MUST select the players before continuing.");
				                return;
				            }
				            else {
				                modeError.setText("");
				                redName = players[rIndex];
				                blueName = players[bIndex];
				                if(rIndex > 1) redPlayer = getPlayer(rIndex - 1);
				                if(bIndex > 1) bluePlayer = getPlayer(bIndex - 1);
				            }
				            
				            if (rIndex > 2 || bIndex > 2) {
				            	maxDepth = Integer.parseInt(maxDepthInput.getText());
				            	if (maxDepth == 0) {
				            		depthError.setText("Depth MUST be greater than 0.");
				            		return;
				            	} else {
				            		if (bluePlayer instanceof AdvancedPlayer) 
				            			((AdvancedPlayer)bluePlayer).setMaxDepth(maxDepth);
				            		else if (bluePlayer instanceof CompetitivePlayer)
				            			((CompetitivePlayer)bluePlayer).setMaxDepth(maxDepth);
				            		
				            		if (redPlayer instanceof AdvancedPlayer) 
				            			((AdvancedPlayer)redPlayer).setMaxDepth(maxDepth);
				            		else if (redPlayer instanceof CompetitivePlayer)
				            			((CompetitivePlayer)redPlayer).setMaxDepth(maxDepth);

				            		depthError.setText("");
				            	}
				            }
				            
				            int wmIndex = workModeList.getSelectedIndex();
				            if (wmIndex == 0 && rIndex > 1 && bIndex > 1) {
				            	workModeError.setText("You MUST select the work mode before continuing.");
				                return;
				            } else {
				            	workModeError.setText("");
				            	workMode = wmIndex - 1;
				            }
							startGame = true;
						}
					}
				} catch (Exception e1) {
				}
			}
        	
        });
        
        redList.addActionListener (new ActionListener () {
            public void actionPerformed(ActionEvent e) {
                if (redList.getSelectedIndex() > 1) {
                	maxDepthInput.setEnabled(true);
                }
                
                if (redList.getSelectedIndex() > 1 && blueList.getSelectedIndex() > 1) {
                	workModeList.setEnabled(true);
                }
                
                if (redList.getSelectedIndex() <= 1 && blueList.getSelectedIndex() > 1) {
                	workModeList.setEnabled(false);
                }
                
                if (redList.getSelectedIndex() <= 1 && blueList.getSelectedIndex() <= 1) {
                	workModeList.setEnabled(false);
                	maxDepthInput.setEnabled(false);
                }
            }
        });
        
        blueList.addActionListener (new ActionListener () {
            public void actionPerformed(ActionEvent e) {
                if (redList.getSelectedIndex() > 1) {
                	maxDepthInput.setEnabled(true);
                }
                
                if (redList.getSelectedIndex() > 1 && blueList.getSelectedIndex() > 1) {
                	workModeList.setEnabled(true);
                }
                
                if (blueList.getSelectedIndex() <= 1 && redList.getSelectedIndex() > 1) {
                	workModeList.setEnabled(false);
                }
                
                if (redList.getSelectedIndex() <= 1 && blueList.getSelectedIndex() <= 1) {
                	workModeList.setEnabled(false);
                	maxDepthInput.setEnabled(false);
                }
            }
        });
	}
	
	private JLabel getEmptyLabel(Dimension d) {
        JLabel label = new JLabel();
        label.setPreferredSize(d);
        return label;
    }

    private boolean startGame;

    private Player getPlayer(int level) {
        if(level == 1) return new BeginnerPlayer();
        else if(level == 2) return new AdvancedPlayer();
        else if(level == 3) return new CompetitivePlayer();
        else return null;
    }
    
    private ActionListener submitListener = new ActionListener() {
    	
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
        	int rIndex = redList.getSelectedIndex();
            int bIndex = blueList.getSelectedIndex();
            if(rIndex==0 || bIndex==0) {
                modeError.setText("You MUST select the players before continuing.");
                return;
            }
            else {
                modeError.setText("");
                redName = players[rIndex];
                blueName = players[bIndex];
                if(rIndex > 1) redPlayer = getPlayer(rIndex - 1);
                if(bIndex > 1) bluePlayer = getPlayer(bIndex - 1);
            }
            
            if (rIndex > 2 || bIndex > 2) {
            	maxDepth = Integer.parseInt(maxDepthInput.getText());
            	if (maxDepth == 0) {
            		depthError.setText("Depth MUST be greater than 0.");
            		return;
            	} else {
            		if (bluePlayer instanceof AdvancedPlayer) 
            			((AdvancedPlayer)bluePlayer).setMaxDepth(maxDepth);
            		else if (bluePlayer instanceof CompetitivePlayer)
            			((CompetitivePlayer)bluePlayer).setMaxDepth(maxDepth);
            		
            		if (redPlayer instanceof AdvancedPlayer) 
            			((AdvancedPlayer)redPlayer).setMaxDepth(maxDepth);
            		else if (redPlayer instanceof CompetitivePlayer)
            			((CompetitivePlayer)redPlayer).setMaxDepth(maxDepth);

            		depthError.setText("");
            	}
            }
            
            int wmIndex = workModeList.getSelectedIndex();
            if (wmIndex == 0 && rIndex > 1 && bIndex > 1) {
            	workModeError.setText("You MUST select the work mode before continuing.");
                return;
            } else {
            	workModeError.setText("");
            	workMode = wmIndex - 1;
            }
            
            m = Integer.parseInt(mInput.getText());
            n = Integer.parseInt(nInput.getText());
            
            if (m > 1 && n > 1 && m < 17 && n < 17) {
            	startGame = true;
                return;
            }
            
            sizeError.setText("M and N MUST be greater than 1 and smaller than 17.");
        }
    };
    
    public void initGUI() throws Exception {

        redPlayer = null;
        bluePlayer = null;

        JPanel grid = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();

        constraints.gridx = 0;
        constraints.gridy = 0;
     

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500,25)), constraints);

        modeError = new JLabel("", SwingConstants.CENTER);
        modeError.setForeground(Color.RED);
        modeError.setPreferredSize(new Dimension(900, 25));
        ++constraints.gridy;
        grid.add(modeError, constraints);

        JPanel modePanel = new JPanel(new GridLayout(2, 2));
        modePanel.setPreferredSize(new Dimension(900, 50));
        modePanel.add(new JLabel("Player-1:", SwingConstants.CENTER));
        modePanel.add(new JLabel("Player-2:", SwingConstants.CENTER));
        modePanel.add(blueList);
        modePanel.add(redList);
        redList.setSelectedIndex(0);
        blueList.setSelectedIndex(0);
        ++constraints.gridy;
        grid.add(modePanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500,25)), constraints);

        depthError = new JLabel("", SwingConstants.CENTER);
        depthError.setForeground(Color.RED);
        depthError.setPreferredSize(new Dimension(500, 25));
        ++constraints.gridy;
        grid.add(depthError, constraints);
        
        JPanel maxDepthPanel = new JPanel(new GridLayout(2, 1));
        maxDepthPanel.setPreferredSize(new Dimension(200, 50));
        maxDepthPanel.add(new JLabel("Max Tree Depth:", SwingConstants.CENTER));
        maxDepthPanel.add(maxDepthInput);
        ++constraints.gridy;
        grid.add(maxDepthPanel, constraints);
        
        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500,25)), constraints);
        
        workModeError = new JLabel("", SwingConstants.CENTER);
        workModeError.setForeground(Color.RED);
        workModeError.setPreferredSize(new Dimension(500, 25));
        ++constraints.gridy;
        grid.add(workModeError, constraints);
        
        JPanel workModePanel = new JPanel(new GridLayout(2, 1));
        workModePanel.setPreferredSize(new Dimension(200, 50));
        workModePanel.add(new JLabel("Work Mode:", SwingConstants.CENTER));
        workModePanel.add(workModeList);
        ++constraints.gridy;
        grid.add(workModePanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500,25)), constraints);
        
        
        ++constraints.gridy;
        grid.add(new JLabel("Select File:"), constraints);
        
        JPanel filePanel = new JPanel(new GridLayout(2, 1));
        filePanel.setPreferredSize(new Dimension(200, 50));
        filePanel.add(fileCheckBox);
        filePanel.add(selectFile);
        ++constraints.gridy;
        grid.add(filePanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500,25)), constraints);

        sizeError = new JLabel("", SwingConstants.CENTER);
        sizeError.setForeground(Color.RED);
        sizeError.setPreferredSize(new Dimension(500, 25));
        ++constraints.gridy;
        grid.add(sizeError, constraints);

        JLabel messageLabel = new JLabel("Board Dimensions:", SwingConstants.CENTER);
        messageLabel.setPreferredSize(new Dimension(400, 50));
        ++constraints.gridy;
        grid.add(messageLabel, constraints);
        
        JPanel dimPanel = new JPanel(new GridLayout(2, 1));
        dimPanel.setPreferredSize(new Dimension(200, 50));
        dimPanel.add(new JLabel("M:", SwingConstants.CENTER));
        dimPanel.add(new JLabel("N:", SwingConstants.CENTER));
        dimPanel.add(mInput);
        dimPanel.add(nInput);
        ++constraints.gridy;
        grid.add(dimPanel, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500, 25)), constraints);

        
        ++constraints.gridy;
        grid.add(submitButton, constraints);

        ++constraints.gridy;
        grid.add(getEmptyLabel(new Dimension(500, 25)), constraints);

        frame.setContentPane(grid);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        startGame = false;
        while(!startGame) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
 
        if (!fileCheckBox.isSelected())
        	new Game(this, frame, n, m, redPlayer, bluePlayer, redName, blueName, workMode);
        else
        	new Game(this, frame, file, redPlayer, bluePlayer, redName, blueName, workMode);
    }
    
    public static void main(String[] args) {
        try {
			new MainFrame().initGUI();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

}
