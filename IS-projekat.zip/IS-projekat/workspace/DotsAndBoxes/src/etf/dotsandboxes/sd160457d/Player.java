package etf.dotsandboxes.sd160457d;

public abstract class Player {

	final static int RED = 0;
	final static int BLUE = 1;
	
	protected int referenceColor;
   	protected final static int cScore = 20;
    protected final static int cThree = 15;
    protected final static int cTwo = 1;
    

    protected int heuristic(final Board board, int color) {
        int value;
        
        if(referenceColor == Board.RED)
            value = cScore * board.getScore(RED) - cScore * board.getScore(BLUE);
        else
            value = cScore * board.getScore(BLUE) - cScore * board.getScore(RED);
        
        return value;
    }

    public abstract Line getNextMove(final Board board, int color);
}
