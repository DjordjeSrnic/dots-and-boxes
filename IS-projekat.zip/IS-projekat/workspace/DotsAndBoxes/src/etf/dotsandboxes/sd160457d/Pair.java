package etf.dotsandboxes.sd160457d;

public class Pair implements Comparable<Pair> {
	
    private int heuristic;
    private Line line;

    public Pair(Line line, int heuristic) {
        this.line = line;
        this.heuristic = heuristic;
    }

    public int getHeuristic() {
        return heuristic;
    }

    public Line getLine() {
        return this.line ;
    }

    void setLine(Line line) {
        this.line = line;
    }
    void setHeuristic(int heuristic) {
        this.heuristic = heuristic;
    }

    @Override
    public int compareTo(Pair pair) {
        return this.heuristic - pair.heuristic;
    }
}
